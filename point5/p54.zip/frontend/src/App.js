// App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route, NavLink } from 'react-router-dom';
import { Menu } from 'semantic-ui-react';
import SignUp from './SignUp';
import LogIn from './LogIn';
import RefreshToken from './RefreshToken';
import LogOut from './LogOut';
import AdminPage from './AdminPage';
import UserPage from './UserPage';
import SuperAdminPage from './SuperAdminPage';
import { RoleProvider, useRoles } from './RoleContext';
import 'semantic-ui-css/semantic.min.css';

// Component pour afficher les rôles actuels de l'utilisateur
function RoleDisplay() {
    const { roles = [] } = useRoles();
    return (
        <div>
            <h3>Current Roles: {roles.join(', ')}</h3>
        </div>
    );
}

// Component pour gérer les routes avec des restrictions basées sur les rôles
function RoutesComponent() {
    const { roles = [] } = useRoles();

    return (
        <Routes>
            <Route path="/signup" element={<SignUp />} />
            <Route path="/login" element={<LogIn />} />
            <Route path="/refresh-token" element={<RefreshToken />} />
            <Route path="/logout" element={<LogOut />} />
            <Route path="/user" element={<UserPage />} />
            <Route path="/admin" element={roles.includes('admin') ? <AdminPage /> : <p>Access Denied</p>} />
            <Route path="/super-admin" element={roles.includes('super_admin') ? <SuperAdminPage /> : <p>Access Denied</p>} />
        </Routes>
    );
}

// App Component qui englobe tout
function App() {
    const { roles = [] } = useRoles();

    return (
        <RoleProvider>
            <Router>
                <Menu pointing secondary>
                    <Menu.Item name="Inscription" as={NavLink} to="/signup" />
                    <Menu.Item name="Connexion" as={NavLink} to="/login" />
                    <Menu.Item name="Rafraîchir le Jeton" as={NavLink} to="/refresh-token" />
                    <Menu.Item name="Déconnexion" as={NavLink} to="/logout" />
                    {roles.includes('user') && <Menu.Item name="User Dashboard" as={NavLink} to="/user" />}
                    {roles.includes('admin') && <Menu.Item name="Admin Dashboard" as={NavLink} to="/admin" />}
                    {roles.includes('super_admin') && <Menu.Item name="Super Admin Dashboard" as={NavLink} to="/super-admin" />}
                </Menu>
                <RoleDisplay />
                <RoutesComponent />
            </Router>
        </RoleProvider>
    );
}

export default App;
