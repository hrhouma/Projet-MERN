// middleware/roleCheck.js
function roleCheck(requiredRoles) {
    return function(req, res, next) {
        const { user } = req;
        if (!user) {
            return res.status(401).json({ error: true, message: "Unauthorized" });
        }

        const hasRequiredRoles = requiredRoles.every(role => user.roles.includes(role));
        if (!hasRequiredRoles) {
            return res.status(403).json({ error: true, message: "Forbidden: Insufficient role" });
        }

        next();
    };
}

export default roleCheck;
