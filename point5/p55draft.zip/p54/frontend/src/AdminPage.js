import React from 'react';

function AdminPage() {
    return (
        <div>
            <h1>Admin Dashboard</h1>
            <p>This page is only accessible to users with admin privileges.</p>
        </div>
    );
}

export default AdminPage;
