// SignUp.js
import React, { useState } from 'react';
import { Button, Form, Message, Dropdown } from 'semantic-ui-react';
import { useRoles } from './RoleContext';  // Import the hook to access roles

function SignUp() {
    const [userData, setUserData] = useState({
        userName: '',
        email: '',
        password: '',
        roles: []
    });
    const [message, setMessage] = useState('');
    const [tokens, setTokens] = useState({ accessToken: '', refreshToken: '' });  // State to hold tokens
    const { updateRoles } = useRoles();  // Use the hook to update roles

    const roleOptions = [
        { key: 'user', text: 'User', value: 'user' },
        { key: 'admin', text: 'Admin', value: 'admin' },
        { key: 'super_admin', text: 'Super Admin', value: 'super_admin' }
    ];

    const handleChange = (e, { name, value }) => setUserData({ ...userData, [name]: value });
    const handleRoleChange = (e, { value }) => setUserData({ ...userData, roles: value });

    const handleSubmit = async () => {
        try {
            const response = await fetch('http://localhost:8080/api/signUp', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(userData)
            });
            const data = await response.json();
            if (!response.ok) throw new Error(data.message);
            setMessage({ success: true, content: 'SignUp successful! Check tokens in console.' });
            setTokens({ accessToken: data.accessToken, refreshToken: data.refreshToken });  // Save tokens to state
            updateRoles(userData.roles);  // Update roles after successful signup
            console.log('Access Token:', data.accessToken);  // Log access token
            console.log('Refresh Token:', data.refreshToken);  // Log refresh token
        } catch (error) {
            setMessage({ success: false, content: error.message || 'SignUp failed!' });
        }
    };

    return (
        <Form onSubmit={handleSubmit} success={!!message.success} error={!message.success}>
            <Form.Input
                label="User Name"
                placeholder="User Name"
                name="userName"
                value={userData.userName}
                onChange={handleChange}
            />
            <Form.Input
                label="Email"
                placeholder="Email"
                name="email"
                value={userData.email}
                onChange={handleChange}
            />
            <Form.Input
                label="Password"
                type="password"
                placeholder="Password"
                name="password"
                value={userData.password}
                onChange={handleChange}
            />
            <Dropdown
                placeholder='Select Role'
                fluid
                multiple
                selection
                options={roleOptions}
                onChange={handleRoleChange}
            />
            <Button type="submit">Sign Up</Button>
            {message.content && <Message
                success={message.success}
                error={!message.success}
                content={message.content}
            />}
        </Form>
    );
}

export default SignUp;

/*
// SignUp.js
import React, { useState } from 'react';
import { Button, Form, Message, Dropdown } from 'semantic-ui-react';
import { useRoles } from './RoleContext';  // Importez le hook pour accéder aux rôles

function SignUp() {
    const [userData, setUserData] = useState({
        userName: '',
        email: '',
        password: '',
        roles: []
    });
    const [message, setMessage] = useState('');
    const { updateRoles } = useRoles();  // Utilisez le hook pour mettre à jour les rôles

    const roleOptions = [
        { key: 'user', text: 'User', value: 'user' },
        { key: 'admin', text: 'Admin', value: 'admin' },
        { key: 'super_admin', text: 'Super Admin', value: 'super_admin' }
    ];

    const handleChange = (e, { name, value }) => setUserData({ ...userData, [name]: value });
    const handleRoleChange = (e, { value }) => setUserData({ ...userData, roles: value });

    const handleSubmit = async () => {
        try {
            const response = await fetch('http://localhost:8080/api/signUp', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(userData)
            });
            const data = await response.json();
            if (!response.ok) throw new Error(data.message);
            setMessage({ success: true, content: 'SignUp successful! Check tokens in console.' });
            updateRoles(userData.roles);  // Mettez à jour les rôles après l'inscription réussie
        } catch (error) {
            setMessage({ success: false, content: error.message || 'SignUp failed!' });
        }
    };

    return (
        <Form onSubmit={handleSubmit} success={!!message.success} error={!message.success}>
            <Form.Input
                label="User Name"
                placeholder="User Name"
                name="userName"
                value={userData.userName}
                onChange={handleChange}
            />
            <Form.Input
                label="Email"
                placeholder="Email"
                name="email"
                value={userData.email}
                onChange={handleChange}
            />
            <Form.Input
                label="Password"
                type="password"
                placeholder="Password"
                name="password"
                value={userData.password}
                onChange={handleChange}
            />
            <Dropdown
                placeholder='Select Role'
                fluid
                multiple
                selection
                options={roleOptions}
                onChange={handleRoleChange}
            />
            <Button type="submit">Sign Up</Button>
            {message.content && <Message
                success={message.success}
                error={!message.success}
                content={message.content}
            />}
        </Form>
    );
}

export default SignUp;
*/