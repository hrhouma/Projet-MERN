import React from 'react';

function UserPage() {
    return (
        <div>
            <h1>User Dashboard</h1>
            <p>All authenticated users can view this page.</p>
        </div>
    );
}

export default UserPage;
