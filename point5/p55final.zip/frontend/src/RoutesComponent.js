import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { useRoles } from './RoleContext'; // Assurez-vous que ce hook est correctement importé
import UserPage from './UserPage';
import AdminPage from './AdminPage';

function RoutesComponent() {
    const { roles } = useRoles();

    return (
        <Routes>
            <Route path="/user" element={<UserPage />} />
            <Route path="/admin" element={roles.includes('admin') ? <AdminPage /> : <p>Access Denied</p>} />
        </Routes>
    );
}

export default RoutesComponent;
