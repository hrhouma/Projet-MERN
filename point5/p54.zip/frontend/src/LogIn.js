// LogIn.js
import React, { useState } from 'react';
import { Button, Form, Message } from 'semantic-ui-react';
import { useRoles } from './RoleContext';  // Importez le hook pour accéder aux rôles

function LogIn() {
    const [credentials, setCredentials] = useState({ email: '', password: '' });
    const [message, setMessage] = useState('');
    const [tokens, setTokens] = useState({ accessToken: '', refreshToken: '' });
    const { updateRoles } = useRoles();  // Utilisez le hook pour mettre à jour les rôles

    const handleChange = (e, { name, value }) => setCredentials({ ...credentials, [name]: value });

    const handleSubmit = async () => {
        try {
            const response = await fetch('http://localhost:8080/api/logIn', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(credentials)
            });
            const data = await response.json();
            if (!response.ok) throw new Error(data.message);
            setMessage({ success: true, content: 'Login successful! Check tokens in console.' });
            setTokens({ accessToken: data.accessToken, refreshToken: data.refreshToken });
            console.log('Access Token:', data.accessToken);
            console.log('Refresh Token:', data.refreshToken);
            updateRoles(data.user?.roles || []);  // Mettez à jour les rôles en utilisant les chaînes optionnelles
        } catch (error) {
            setMessage({ success: false, content: error.message || 'Login failed!' });
        }
    };

    return (
        <Form onSubmit={handleSubmit} success={message.success} error={!message.success}>
            <Form.Input
                label="Email"
                placeholder="Email"
                name="email"
                value={credentials.email}
                onChange={handleChange}
            />
            <Form.Input
                label="Password"
                type="password"
                placeholder="Password"
                name="password"
                value={credentials.password}
                onChange={handleChange}
            />
            <Button type="submit">Log In</Button>
            {message.content && <Message
                success={message.success}
                error={!message.success}
                content={message.content}
            />}
            <div>
                <p>Access Token: {tokens.accessToken}</p>
                <p>Refresh Token: {tokens.refreshToken}</p>
            </div>
        </Form>
    );
}

export default LogIn;
