import React from 'react';
import { BrowserRouter as Router, Routes, Route, NavLink } from 'react-router-dom';
import { Menu, Container } from 'semantic-ui-react';
import SignUp from './SignUp';
import LogIn from './LogIn';
import RefreshToken from './RefreshToken';
import LogOut from './LogOut';
import AdminPage from './AdminPage';
import UserPage from './UserPage';
import SuperAdminPage from './SuperAdminPage';
import { RoleProvider, useRoles } from './RoleContext';
import 'semantic-ui-css/semantic.min.css';

function App() {
    return (
        <RoleProvider>  {/* Assurez-vous que le RoleProvider englobe tout */}
            <Router>
                <Container style={{ marginTop: '20px' }}>
                    <Menu pointing secondary>
                        <Menu.Item name="Inscription" as={NavLink} to="/signup" />
                        <Menu.Item name="Connexion" as={NavLink} to="/login" />
                        <Menu.Item name="Rafraîchir le Jeton" as={NavLink} to="/refresh-token" />
                        <Menu.Item name="Déconnexion" as={NavLink} to="/logout" />
                        <MenuRoles />
                    </Menu>
                    <RoutesComponent />
                </Container>
            </Router>
        </RoleProvider>
    );
}

function MenuRoles() {
    const { roles } = useRoles();
    return (
        <>
            {roles.includes('super_admin') && <Menu.Item name="Super Admin Dashboard" as={NavLink} to="/super-admin" />}
        </>
    );
}

function RoutesComponent() {
    const { roles } = useRoles();
    return (
        <Routes>
            <Route path="/signup" element={<SignUp />} />
            <Route path="/login" element={<LogIn />} />
            <Route path="/refresh-token" element={<RefreshToken />} />
            <Route path="/logout" element={<LogOut />} />
            <Route path="/user" element={<UserPage />} />
            <Route path="/admin" element={roles.includes('admin') ? <AdminPage /> : <p>Access Denied</p>} />
            <Route path="/super-admin" element={roles.includes('super_admin') ? <SuperAdminPage /> : <p>Access Denied</p>} />
        </Routes>
    );
}

export default App;
