// RoleContext.js
import React, { createContext, useContext, useState } from 'react';

const RoleContext = createContext({ roles: [], updateRoles: () => {} });

export const useRoles = () => useContext(RoleContext);

export const RoleProvider = ({ children }) => {
    const [roles, setRoles] = useState([]);

    const updateRoles = (newRoles) => {
        setRoles(newRoles);
    };

    return (
        <RoleContext.Provider value={{ roles, updateRoles }}>
            {children}
        </RoleContext.Provider>
    );
};
