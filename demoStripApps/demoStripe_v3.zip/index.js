const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const stripe = require('stripe')('sk_live_XXX7');

const app = express();
const port = process.env.PORT || 3000;

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Configuration du moteur de rendu
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Route pour afficher le formulaire de paiement
app.get('/', function(req, res) {
    res.render('Home', {
        key: 'pk_live_XXXXF7T' 
    });
});

// Route pour traiter le paiement
app.post('/payment', function(req, res) {
    stripe.customers.create({
        email: req.body.stripeEmail,
        source: req.body.stripeToken,
        name: req.body.stripeName,
        address: {
            line1: req.body.stripeLine1,
            postal_code: req.body.stripePostalCode,
            city: req.body.stripeCity,
            state: req.body.stripeState,
            country: req.body.stripeCountry,
        }
    })
    .then((customer) => {
        return stripe.charges.create({
            amount: 200, // $2 en centimes
            description: 'Produits d\'intelligence artificielle',
            currency: 'cad',
            customer: customer.id
        });
    })
    .then((charge) => {
        res.send('Success'); // Si tout se passe bien
    })
    .catch((err) => {
        res.send(err); // Si une erreur survient
    });
});

// Démarrer le serveur
app.listen(port, function(error) {
    if (error) throw error;
    console.log(`Serveur démarré avec succès sur le port ${port}`);
});
