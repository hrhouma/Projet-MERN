import React from 'react';

const PaymentSuccess = () => {
  return (
    <div>
      <h1>Payment Success</h1>
      <p>Your payment agreement was created successfully.</p>
    </div>
  );
};

export default PaymentSuccess;
