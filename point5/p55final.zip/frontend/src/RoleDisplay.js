import React from 'react';
import { useRoles } from './RoleContext'; // Assurez-vous que ce hook est correctement importé

function RoleDisplay() {
    const { roles } = useRoles();

    return (
        <div>
            <h3>Current Roles: {roles.join(', ')}</h3>
        </div>
    );
}

export default RoleDisplay;
