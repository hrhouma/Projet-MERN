import React from 'react';
import { BrowserRouter as Router, Route, Routes, NavLink } from 'react-router-dom';
import { Menu } from 'semantic-ui-react';
import SignUp from './SignUp';
import LogIn from './LogIn';
import RefreshToken from './RefreshToken';
import LogOut from './LogOut';
import 'semantic-ui-css/semantic.min.css';

function App() {
  return (
    <Router>
      <Menu pointing secondary>
        <Menu.Item
          name="Inscription"
          as={NavLink}
          to="/signup"
        />
        <Menu.Item
          name="Connexion"
          as={NavLink}
          to="/login"
        />
        <Menu.Item
          name="Rafraîchir le Jeton"
          as={NavLink}
          to="/refresh-token"
        />
        <Menu.Item
          name="Déconnexion"
          as={NavLink}
          to="/logout"
        />
      </Menu>
      <Routes>
        <Route path="/signup" element={<SignUp />} />
        <Route path="/login" element={<LogIn />} />
        <Route path="/refresh-token" element={<RefreshToken />} />
        <Route path="/logout" element={<LogOut />} />
      </Routes>
    </Router>
  );
}

export default App;
