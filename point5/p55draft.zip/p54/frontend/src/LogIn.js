// LogIn.js
import React, { useState } from 'react';
import { Button, Form, Message } from 'semantic-ui-react';
import { useRoles } from './RoleContext';

function LogIn() {
    const [credentials, setCredentials] = useState({ email: '', password: '' });
    const [message, setMessage] = useState('');
    const [tokens, setTokens] = useState({ accessToken: '', refreshToken: '' });
    const { updateRoles } = useRoles();

    const handleChange = (e, { name, value }) => setCredentials({ ...credentials, [name]: value });

    const handleSubmit = async () => {
        try {
            const response = await fetch('http://localhost:8080/api/logIn', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(credentials)
            });
            const data = await response.json();
            if (!response.ok) throw new Error(data.message || "Failed to login");

            console.log('Received Data:', data); // Log the entire response data

            if (data.accessToken && data.refreshToken) {
                setTokens({ accessToken: data.accessToken, refreshToken: data.refreshToken });
                console.log('Access Token:', data.accessToken);
                console.log('Refresh Token:', data.refreshToken);
            } else {
                throw new Error("Tokens not provided in the response");
            }

            if (data.user && data.user.roles) {
                updateRoles(data.user.roles);
            } else {
                console.warn("No roles provided in the response");
            }

            setMessage({ success: true, content: 'Login successful! Check tokens in the console.' });
        } catch (error) {
            console.error('Login Error:', error);
            setMessage({ success: false, content: error.message || 'Login failed!' });
        }
    };

    return (
        <Form onSubmit={handleSubmit} success={message.success} error={!message.success}>
            <Form.Input
                label="Email"
                placeholder="Email"
                name="email"
                value={credentials.email}
                onChange={handleChange}
            />
            <Form.Input
                label="Password"
                type="password"
                placeholder="Password"
                name="password"
                value={credentials.password}
                onChange={handleChange}
            />
            <Button type="submit">Log In</Button>
            {message.content && <Message
                success={message.success}
                error={!message.success}
                content={message.content}
            />}
            <div>
                <p>Access Token: {tokens.accessToken || 'No access token received'}</p>
                <p>Refresh Token: {tokens.refreshToken || 'No refresh token received'}</p>
            </div>
        </Form>
    );
}

export default LogIn;
