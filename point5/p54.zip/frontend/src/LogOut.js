import React, { useState } from 'react';
import { Button, Form, Message } from 'semantic-ui-react';

function LogOut() {
    const [refreshToken, setRefreshToken] = useState('');
    const [message, setMessage] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await fetch('http://localhost:8080/api/refreshToken', {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ refreshToken })
            });
            const data = await response.json();
            if (response.ok) {
                setMessage({ success: true, content: 'Logged out successfully.' });
            } else {
                throw new Error(data.message);
            }
        } catch (error) {
            setMessage({ success: false, content: error.message || 'An error occurred' });
        }
    };

    return (
        <Form onSubmit={handleSubmit} success={message.success} error={!message.success}>
            <Form.Input
                label="Refresh Token"
                placeholder="Enter your refresh token"
                value={refreshToken}
                onChange={(e) => setRefreshToken(e.target.value)}
            />
            <Button type="submit">Log Out</Button>
            {message.content && <Message
                success={message.success}
                error={!message.success}
                content={message.content}
            />}
        </Form>
    );
}

export default LogOut;

/*import React, { useState } from 'react';
import { Button, Form, Message } from 'semantic-ui-react';
import axios from 'axios';

function LogOut() {
    const [refreshToken, setRefreshToken] = useState('');
    const [message, setMessage] = useState('');

    const handleSubmit = async () => {
        try {
            await axios.delete('http://localhost:8080/api/refreshToken', { data: { refreshToken } });
            setMessage({ success: true, content: 'Logged out successfully.' });
        } catch (error) {
            setMessage({ success: false, content: error.response.data.message });
        }
    };

    return (
        <Form onSubmit={handleSubmit} success={message.success} error={!message.success}>
            <Form.Input
                label="Refresh Token"
                placeholder="Enter your refresh token"
                value={refreshToken}
                onChange={(e) => setRefreshToken(e.target.value)}
            />
            <Button type="submit">Log Out</Button>
            {message.content && <Message
                success={message.success}
                error={!message.success}
                content={message.content}
            />}
        </Form>
    );
}

export default LogOut;
*/