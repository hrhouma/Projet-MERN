import express from 'express';
import roleCheck from '../middleware/roleCheck.js';  // Assurez-vous que ce fichier est bien créé et configuré

const router = express.Router();

// Route accessible uniquement par les administrateurs
router.get('/dashboard', roleCheck(['admin']), (req, res) => {
    res.status(200).json({ message: "Bienvenue sur le tableau de bord administratif" });
});

// Autre exemple de route admin pour des actions spécifiques
router.post('/manage-users', roleCheck(['admin']), (req, res) => {
    // Logique pour gérer les utilisateurs (ex: créer, supprimer des utilisateurs)
    res.status(200).json({ message: "Gestion des utilisateurs réalisée" });
});

export default router;
