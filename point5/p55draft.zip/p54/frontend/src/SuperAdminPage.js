// SuperAdminPage.js
import React from 'react';
import { Header, Segment, Icon } from 'semantic-ui-react';

function SuperAdminPage() {
    return (
        <Segment padded="very" style={{ backgroundColor: '#f9f9f9', minHeight: '80vh', marginTop: '20px' }}>
            <Header as='h2' icon textAlign='center'>
                <Icon name='chess king' circular />
                <Header.Content>Super Admin Dashboard</Header.Content>
            </Header>
            <p style={{ textAlign: 'center', fontSize: '1.2em' }}>
                This page is only accessible to users with super admin privileges.
                Here, you can manage all the critical aspects of the application.
            </p>
        </Segment>
    );
}

export default SuperAdminPage;
