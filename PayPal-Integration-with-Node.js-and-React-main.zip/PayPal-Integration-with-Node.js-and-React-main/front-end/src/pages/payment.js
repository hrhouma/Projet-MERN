import PaymentPage from "../components/payment";

function PaymentPage(){
        return (
            <>
            <PaymentPage/>
            </>
                    
                )
}
export default PaymentPage;
