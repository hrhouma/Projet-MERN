import React, { useState } from 'react';
import { Button, Form, Message } from 'semantic-ui-react';

function SignUp() {
    const [userData, setUserData] = useState({ userName: '', email: '', password: '' });
    const [message, setMessage] = useState('');
    const [tokens, setTokens] = useState({ accessToken: '', refreshToken: '' });

    const handleChange = (e, { name, value }) => setUserData({ ...userData, [name]: value });

    const handleSubmit = async () => {
        try {
            const response = await fetch('http://localhost:8080/api/signUp', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(userData)
            });
            const data = await response.json();
            if (!response.ok) throw new Error(data.message);
            setMessage({ success: true, content: 'SignUp successful! Check tokens in console.' });
            setTokens({ accessToken: data.accessToken, refreshToken: data.refreshToken });
            console.log('Access Token:', data.accessToken);
            console.log('Refresh Token:', data.refreshToken);
        } catch (error) {
            setMessage({ success: false, content: error.message || 'SignUp failed!' });
        }
    };

    return (
        <Form onSubmit={handleSubmit} success={message.success} error={!message.success}>
            <Form.Input
                label="User Name"
                placeholder="User Name"
                name="userName"
                value={userData.userName}
                onChange={handleChange}
            />
            <Form.Input
                label="Email"
                placeholder="Email"
                name="email"
                value={userData.email}
                onChange={handleChange}
            />
            <Form.Input
                label="Password"
                type="password"
                placeholder="Password"
                name="password"
                value={userData.password}
                onChange={handleChange}
            />
            <Button type="submit">Sign Up</Button>
            {message.content && <Message
                success={message.success}
                error={!message.success}
                content={message.content}
            />}
            <div>
                <p>Access Token: {tokens.accessToken}</p>
                <p>Refresh Token: {tokens.refreshToken}</p>
            </div>
        </Form>
    );
}

export default SignUp;
