Pour démarrer l'application:
---------------------------

L'application nécessite MongoDB.

Installation:
------------
o Se rendre dans le dossier ./client -> npm install
o Se rendre dans le dossier ./server -> npm install

Lancement:
---------
o Se rendre dans le dossier ./client -> npm start
  L'application devrait être lancée automatiquement dans le navigateur par défaut.
  Si ce n'est pas le cas, ouvrir le navigateur et se rendre à l'adresse suivante:
    http://localhost/3000

o Se rendre dans le dossier ./server -> node index.js
  Un message de bienvenue apparait sur la console.
  Pour vérifier que l'API est à l'écoute, ouvrir le navigateur et se rendre à l'adresse suivante:
    http://localhost/9000


