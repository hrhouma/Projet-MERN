import React, { useState } from 'react';
import { Button, Form, Message } from 'semantic-ui-react';
import axios from 'axios';

function RefreshToken() {
    const [refreshToken, setRefreshToken] = useState('');
    const [message, setMessage] = useState('');

    const handleSubmit = async () => {
        try {
            const response = await axios.post('http://localhost:8080/api/refreshToken', { refreshToken });
            setMessage({ success: true, content: 'Token refreshed successfully. New Token: ' + response.data.accessToken });
        } catch (error) {
            setMessage({ success: false, content: error.response.data.message });
        }
    };

    return (
        <Form onSubmit={handleSubmit} success={message.success} error={!message.success}>
            <Form.Input
                label="Refresh Token"
                placeholder="Enter your refresh token"
                value={refreshToken}
                onChange={(e) => setRefreshToken(e.target.value)}
            />
            <Button type="submit">Refresh Token</Button>
            {message.content && <Message
                success={message.success}
                error={!message.success}
                content={message.content}
            />}
        </Form>
    );
}

export default RefreshToken;
